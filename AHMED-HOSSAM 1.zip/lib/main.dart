import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:email_validator/email_validator.dart';
import 'package:url_launcher/url_launcher.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    const TouristGuideApp(),
  );
}

const Map<String, List<Map<String, String>>> _allLandmarks = {
  'القاهرة': [
    {
      'الأهرامات':
          'https://lh5.googleusercontent.com/p/AF1QipNCPVoHLvf2HH0mKKWPkiPVV6fEy7iWaMLrTpEx=w408-h264-k-no',
      'video': 'https://youtu.be/Bo14lIipGaM?si=-d1k3BKzsmOtRlWz',
      'location': 'https://maps.app.goo.gl/7zN6yTJRvwXvGZZw5',
    },
    {
      'المتحف المصري':
          'https://lh5.googleusercontent.com/p/AF1QipPszMaddvRDYeH093X1_snlGEXKBvfJRs7sv7E=w408-h306-k-no',
      'video': 'https://youtu.be/W8_I_-2KSZM?si=pbEwFdZkNizN05VE',
      'location': 'https://maps.app.goo.gl/sD5bHspzA3883ofo9',
    },
    {
      ' قلعة صلاح الدين الايوبي ':
          'https://lh5.googleusercontent.com/p/AF1QipPrygwy2lJNJSWhx3jjQUAwn78BtG3lFgMHtO-g=w408-h249-k-no',
      'video': 'https://youtu.be/V5H9HRnTXTY?si=whMasYpR_dr4mGIS',
      'location': 'https://maps.app.goo.gl/fG3gGSkC7a5p6X5KA',
    },
    {
      'خان الخليلي':
          'https://iresizer.devops.arabiaweather.com/resize?url=https://adminassets.devops.arabiaweather.com/sites/default/files/uploads/Khan-El-Khalili%203.jpg&size=850x0&force_webp=1',
      'video': 'https://youtu.be/fJCMyF16aK4?si=mpPaA9pqGZypFxIk',
      'location': 'https://maps.app.goo.gl/e6pFkmxKtL3nAsny7',
    },
  ],
  'الإسكندرية': [
    {
      'قلعة قايتباي':
          'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c3/Qaitbay_Castle_in_Alexandria.jpg/390px-Qaitbay_Castle_in_Alexandria.jpg',
      'video':
          'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4',
      'location': 'https://maps.app.goo.gl/pc3Stq4aZXHsq9HQ6',
    },
    {
      'المكتبة الإسكندرية':
          'https://lh5.googleusercontent.com/p/AF1QipMStnCHCp7zkLSE-Pm0WZna1KtzwejQVByLYjEq=w408-h305-k-no',
      'video':
          'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4',
      'location': 'https://maps.app.goo.gl/dsnx5qc9guuGe5V58',
    },
    {
      'متحف المجوهرات الملكية':
          'https://i.pinimg.com/736x/79/41/d8/7941d8fa1805ac29aa349f0924359515.jpg',
      'video':
          'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4',
      'location': 'https://maps.app.goo.gl/9n6r7CuFGeAQH2r48',
    },
  ],
  'الأقصر': [
    {
      'معبد الكرنك':
          'https://media-cdn.tripadvisor.com/media/photo-s/1a/55/02/28/caption.jpg ',
      'video':
          'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4',
      'location': 'https://maps.app.goo.gl/fswAgjmrxFc2cYF19',
    },
    {
      'وادي الملوك':
          'https://beta.sis.gov.eg/media/272658/%D9%88%D8%A7%D8%AF%D9%89-%D8%A7%D9%84%D9%85%D9%84%D9%88%D9%832-1.jpg',
      'video':
          'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4',
      'location': 'https://maps.app.goo.gl/qLxAFzG4z1557SG47',
    },
    {
      'معبد الأقصر':
          'https://cdn.alweb.com/thumbs/travel/article/fit710x532/%D8%AA%D8%B9%D8%B1%D9%81-%D8%B9%D9%84%D9%89-%D8%A3%D8%AC%D9%85%D9%84-%D8%A7%D9%84%D8%A3%D9%86%D8%B4%D8%B7%D8%A9-%D8%B9%D9%86%D8%AF-%D8%B2%D9%8A%D8%A7%D8%B1%D8%A9-%D9%85%D8%B9%D8%A8%D8%AF-%D8%A7%D9%84%D8%A3%D9%82%D8%B5%D8%B1.jpg',
      'video':
          'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4',
      'location': 'https://maps.app.goo.gl/WBdwb2wdxdo95AL98',
    },
  ],
  'أسوان': [
    {
      'معبد فيلة':
          'https://www.urtrips.com/wp-content/uploads/2018/05/Philae-Temple-Inside.jpg',
      'video':
          'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/TearsOfSteel.mp4',
      'location': 'https://maps.app.goo.gl/Bir9uLgZWeoFerjw8',
    },
    {
      'معبد أبو سمبل':
          'https://img.youm7.com/ArticleImgs/2017/12/25/1173217-%D8%B3%D8%A7%D8%A6%D8%AD%D8%A7%D9%86-%D9%8A%D9%82%D9%81%D8%A7%D9%86-%D8%A3%D9%85%D8%A7%D9%85-%D9%85%D8%B9%D8%A8%D8%AF-%D8%A3%D8%A8%D9%88-%D8%B3%D9%85%D8%A8%D9%84.jpg',
      'video':
          'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4',
      'location': 'https://maps.app.goo.gl/QWaFYMmLo4E5sMLz7',
    },
  ],
  'شرم الشيخ': [
    {
      'خليج نعمة':
          'https://media.gemini.media/img/large/2021/7/31/2021_7_31_13_54_5_832.jpg',
      'video':
          'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WhatCarCanYouGetForAGrand.mp4',
      'location': 'https://maps.app.goo.gl/HYXDBjrnTFHqhJik6',
    },
    {
      'محمية رأس محمد':
          'https://media.gemini.media/img/large/2019/7/24/2019_7_24_11_2_13_923.jpg',
      'video':
          'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
      'location': 'https://maps.app.goo.gl/XY61qF155g47sAnE8',
    },
    {
      'مسجد الصحابة ':
          'https://watanimg.elwatannews.com/image_archive/original_lower_quality/12984148651634821170.jpg',
      'video':
          'http://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
      'location': 'https://maps.app.goo.gl/R13qxUKFS51Bcmf39',
    },
  ],
};

class UserInformation {
  String disabilityType = '';
  String guestName = '';
  String email = '';
  String password = '';
  List<String> selectedLandmarks = [];
  File? image;
}

class TouristGuideApp extends StatefulWidget {
  const TouristGuideApp({Key? key}) : super(key: key);

  @override
  _TouristGuideAppState createState() => _TouristGuideAppState();
}

class _TouristGuideAppState extends State<TouristGuideApp> {
  bool _isDarkMode = false;
  bool _showWelcomeScreen = true;

  @override
  void initState() {
    super.initState();
    Timer(const Duration(seconds: 3), () {
      setState(() {
        _showWelcomeScreen = false;
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'دليل السائح للأشخاص ذوي الاحتياجات الخاصة',
      theme: _isDarkMode
          ? ThemeData.dark().copyWith(
              primaryColor: const Color(0xff02111d),
              scaffoldBackgroundColor: const Color(0xff152d47),
              appBarTheme: const AppBarTheme(
                backgroundColor: Color(0xff050c13),
              ),
              textTheme: const TextTheme(
                headline1: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Color(0xff5e0404),
                ),
                headline2: TextStyle(fontSize: 18, color: Color(0xffc65757)),
                bodyText1: TextStyle(fontSize: 16, color: Color(0xff934444)),
                button: TextStyle(fontSize: 18, color: Colors.white),
              ),
            )
          : ThemeData.light().copyWith(
              primaryColor: const Color(0xff11171b),
              scaffoldBackgroundColor: const Color(0xffffffff),
              appBarTheme: const AppBarTheme(
                backgroundColor: Color(0xff12191f),
              ),
              textTheme: const TextTheme(
                headline1: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.black,
                ),
                headline2: TextStyle(fontSize: 18, color: Colors.black),
                bodyText1: TextStyle(fontSize: 16, color: Colors.black),
                button: TextStyle(fontSize: 18, color: Color(0xffad5050)),
              ),
            ),
      home: _showWelcomeScreen
          ? WelcomeScreen()
          : UserLoginPage(toggleDarkMode: _toggleDarkMode),
    );
  }

  void _toggleDarkMode() {
    setState(() {
      _isDarkMode = !_isDarkMode;
    });
  }
}

class WelcomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.network(
              'https://upload.wikimedia.org/wikipedia/commons/thumb/f/f2/MUTCD_D9-6.svg/800px-MUTCD_D9-6.svg.png',
              width: 200,
              height: 200,
            ),
            SizedBox(height: 20),
            Text(
              'أهلاً بك في عالم الاكتشاف بلا حواجز ',
              style: TextStyle(fontSize: 25),
            ),
            SizedBox(height: 20),
            // استخدم عنصر واجهة مستخدم مخصص لعرض علامة التحميل بشكل مبدع
            CreativeLoadingIndicator(),
          ],
        ),
      ),
    );
  }
}

class CreativeLoadingIndicator extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 100,
      height: 100,
      child: Stack(
        alignment: Alignment.center,
        children: [
          CircularProgressIndicator(
            strokeWidth: 8,
            valueColor: AlwaysStoppedAnimation<Color>(Colors.blue),
          ),
          SizedBox(
            width: 50,
            height: 50,
            child: Stack(
              children: [
                Positioned(
                  left: 0,
                  child: Dot(),
                ),
                Positioned(
                  top: 0,
                  child: Dot(),
                ),
                Positioned(
                  right: 0,
                  child: Dot(),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class Dot extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 10,
      height: 10,
      decoration: BoxDecoration(
        color: Color(0xff0081ff),
        shape: BoxShape.circle,
      ),
    );
  }
}

class UserLoginPage extends StatelessWidget {
  final UserInformation userInformation = UserInformation();
  final VoidCallback toggleDarkMode;

  UserLoginPage({Key? key, required this.toggleDarkMode}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(' تسجيل الدخول'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            const Text(
              'قم بتسجيل الدخول',
              style: TextStyle(fontSize: 30),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 30),
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => GuestInfoPage(userInformation),
                  ),
                );
              },
              style: ElevatedButton.styleFrom(
                primary: const Color(0xff02070c),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15.0),
                ),
              ),
              child: const Padding(
                padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                child: Text(
                  'تسجيل الدخول',
                  style: TextStyle(fontSize: 18),
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            IconButton(
              icon: const Icon(Icons.home),
              onPressed: () {
                Navigator.popUntil(context, ModalRoute.withName('/'));
              },
            ),
            IconButton(
              icon: const Icon(Icons.brightness_6),
              onPressed: toggleDarkMode,
            ),
          ],
        ),
      ),
    );
  }
}

class GuestInfoPage extends StatefulWidget {
  final UserInformation userInformation;

  GuestInfoPage(this.userInformation, {Key? key}) : super(key: key);

  @override
  _GuestInfoPageState createState() => _GuestInfoPageState();
}

class _GuestInfoPageState extends State<GuestInfoPage> {
  TextEditingController nameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('معلومات الضيف'),
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              const Text(
                ': نوع الأحتياج الخاص',
                style: TextStyle(fontSize: 30),
              ),
              const SizedBox(height: 20),
              ElevatedButton.icon(
                onPressed: () {
                  _showDisabilityDialog(context);
                },
                style: ElevatedButton.styleFrom(
                  primary: const Color(0xff000000),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15.0),
                  ),
                ),
                icon: Icon(Icons.accessibility),
                label: Text(
                  widget.userInformation.disabilityType.isEmpty
                      ? ' اختر نوع الأحتياج الخاص'
                      : widget.userInformation.disabilityType,
                  style: TextStyle(fontSize: 18),
                ),
              ),
              const SizedBox(height: 20),
              _buildTextField(
                controller: nameController,
                label: 'الاسم',
                hintText: 'أدخل اسمك',
                prefixIcon: Icons.person,
              ),
              const SizedBox(height: 20),
              _buildTextField(
                controller: emailController,
                label: 'البريد الإلكتروني',
                hintText: 'أدخل بريدك الإلكتروني',
                prefixIcon: Icons.email,
                isEmail: true,
              ),
              const SizedBox(height: 20),
              _buildTextField(
                controller: passwordController,
                label: 'كلمة المرور',
                hintText: 'أدخل كلمة المرور',
                prefixIcon: Icons.lock,
                isPassword: true,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: () {
                  bool isValidEmail =
                      EmailValidator.validate(emailController.text);

                  if (widget.userInformation.disabilityType.isNotEmpty &&
                      nameController.text.isNotEmpty &&
                      isValidEmail &&
                      passwordController.text.isNotEmpty) {
                    widget.userInformation.guestName = nameController.text;
                    widget.userInformation.email = emailController.text;
                    widget.userInformation.password = passwordController.text;
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => LandmarksPage(
                            widget.userInformation, _allLandmarks),
                      ),
                    );
                  } else {
                    // إذا كانت هناك بيانات مفقودة، فأظهر رسالة التنبيه
                    String missingDataMessage = '';
                    if (widget.userInformation.disabilityType.isEmpty)
                      missingDataMessage +=
                          '                          نوع الاحتياج الخاص -\n';
                    if (nameController.text.isEmpty)
                      missingDataMessage +=
                          '                                            الاسم -\n';
                    if (!isValidEmail)
                      missingDataMessage +=
                          '                              البريد الإلكتروني -\n';
                    if (passwordController.text.isEmpty)
                      missingDataMessage +=
                          '                                   كلمة المرور -\n';
                    _showAlertDialog(context,
                        '                  : الرجاء إدخال البيانات التالية\n$missingDataMessage');
                  }
                },
                style: ElevatedButton.styleFrom(
                  primary: const Color(0xff000000),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(15.0),
                  ),
                ),
                child: const Padding(
                  padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                  child: Text(
                    'التالي',
                    style: TextStyle(fontSize: 18),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            IconButton(
              icon: const Icon(Icons.home),
              onPressed: () {
                Navigator.popUntil(context, ModalRoute.withName('/'));
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showDisabilityDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('اختر نوع الاحتياج الخاص'),
          content: SingleChildScrollView(
            child: Column(
              children: [
                _buildDisabilityButton(context, 'بصرية'),
                SizedBox(height: 15),
                _buildDisabilityButton(context, 'سمعية'),
                SizedBox(height: 15),
                _buildDisabilityButton(context, 'حركية'),
                SizedBox(height: 15),
                _buildDisabilityButton(context, 'ذهنية'),
                SizedBox(height: 15),
              ],
            ),
          ),
        );
      },
    );
  }

  ElevatedButton _buildDisabilityButton(BuildContext context, String type) {
    return ElevatedButton(
      onPressed: () {
        Navigator.of(context).pop();
        setState(() {
          widget.userInformation.disabilityType = type;
        });
      },
      child: Text(
        type,
        style: TextStyle(fontSize: 18),
      ),
      style: ElevatedButton.styleFrom(
        primary: widget.userInformation.disabilityType == type
            ? Theme.of(context).primaryColor
            : const Color(0xff000000),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10.0),
        ),
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required String hintText,
    required IconData prefixIcon,
    bool isEmail = false,
    bool isPassword = false,
  }) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: TextField(
        controller: controller,
        keyboardType: isEmail ? TextInputType.emailAddress : TextInputType.text,
        obscureText: isPassword,
        decoration: InputDecoration(
          labelText: label,
          hintText: hintText,
          prefixIcon: Icon(prefixIcon),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(15),
          ),
        ),
      ),
    );
  }

  void _showAlertDialog(BuildContext context, String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('                                   تنبيه'),
          content: Text(message),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: const Text('حسنًا'),
            ),
          ],
        );
      },
    );
  }
}

class LandmarksPage extends StatelessWidget {
  final UserInformation userInformation;
  final Map<String, List<Map<String, String>>> landmarks;

  LandmarksPage(this.userInformation, this.landmarks, {Key? key})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('المعالم السياحية'),
      ),
      body: ListView.builder(
        itemCount: landmarks.keys.length,
        itemBuilder: (context, index) {
          String city = landmarks.keys.elementAt(index);
          List<Map<String, String>> cityLandmarks = landmarks[city]!;
          return Card(
            elevation: 3.0,
            margin: EdgeInsets.all(10.0),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(15.0),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Text(
                    city,
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                    ),
                    textAlign: TextAlign.center,
                  ),
                ),
                GridView.builder(
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    crossAxisSpacing: 4.0,
                    mainAxisSpacing: 4.0,
                  ),
                  itemCount: cityLandmarks.length,
                  itemBuilder: (context, index) {
                    String landmarkName =
                        cityLandmarks[index].keys.elementAt(0);
                    String landmarkImage = cityLandmarks[index][landmarkName]!;
                    String videoUrl = cityLandmarks[index]['video']!;
                    String locationUrl = cityLandmarks[index]['location']!;

                    IconData iconData;
                    if (videoUrl.isNotEmpty) {
                      iconData = Icons.video_library;
                    } else {
                      iconData = Icons.map;
                    }

                    return GestureDetector(
                      onTap: () {
                        LandmarkDetailsPage(
                          context,
                          landmarkName,
                          landmarkImage,
                          videoUrl,
                          locationUrl,
                        );
                      },
                      child: Card(
                        elevation: 3.0,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15.0),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.stretch,
                          children: <Widget>[
                            Expanded(
                              flex: 2,
                              child: ClipRRect(
                                borderRadius: BorderRadius.only(
                                  topLeft: Radius.circular(15),
                                  topRight: Radius.circular(15),
                                ),
                                child: Image.network(
                                  landmarkImage,
                                  fit: BoxFit.fill,
                                ),
                              ),
                            ),
                            Expanded(
                              flex: 1,
                              child: Padding(
                                padding: const EdgeInsets.all(8.0),
                                child: Text(
                                  landmarkName,
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                              ),
                            ),
                            SizedBox(
                              width: double.infinity,
                              child: CustomButton(
                                onPressed: () {
                                  if (videoUrl.isNotEmpty) {
                                    launch(videoUrl);
                                  } else {
                                    launch(locationUrl);
                                  }
                                },
                                text: videoUrl.isNotEmpty
                                    ? 'شاهد الفيديو'
                                    : 'عرض الموقع على الخريطة',
                                icon: iconData,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ],
            ),
          );
        },
      ),
      bottomNavigationBar: BottomAppBar(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            IconButton(
              icon: const Icon(Icons.home),
              onPressed: () {
                Navigator.popUntil(context, ModalRoute.withName('/'));
              },
            ),
          ],
        ),
      ),
    );
  }

  void LandmarkDetailsPage(BuildContext context, String landmarkName,
      String landmarkImage, String videoUrl, String locationUrl) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => LandmarkDetailsScreen(
          landmarkName: landmarkName,
          landmarkImage: landmarkImage,
          videoUrl: videoUrl,
          locationUrl: locationUrl,
        ),
      ),
    );
  }
}

class CustomButton extends StatelessWidget {
  final VoidCallback onPressed;
  final String text;
  final IconData icon;
  final double buttonWidth; // إضافة عرض الزر كمتغير

  const CustomButton({
    required this.onPressed,
    required this.text,
    required this.icon,
    this.buttonWidth = 200, // تحديد عرض افتراضي للزر
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialButton(
      onPressed: onPressed,
      color: Theme.of(context).primaryColor,
      textColor: Colors.white,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(15),
      ),
      child: SizedBox(
        // استخدام SizedBox لتحديد العرض
        width: buttonWidth,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon),
            SizedBox(width: 8),
            Flexible(
              // استخدام Flexible لضمان تناسب النص
              child: Text(
                text,
                style: TextStyle(fontSize: 16),
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class LandmarkDetailsScreen extends StatelessWidget {
  final String landmarkName;
  final String landmarkImage;
  final String videoUrl;
  final String locationUrl;

  const LandmarkDetailsScreen({
    required this.landmarkName,
    required this.landmarkImage,
    required this.videoUrl,
    required this.locationUrl,
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(landmarkName),
      ),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            child: Stack(
              children: [
                Image.network(
                  landmarkImage,
                  fit: BoxFit.fill,
                  height: double.infinity,
                  width: double.infinity,
                ),
                Positioned(
                  top: 250, // تعديل الارتفاع حسب الحاجة
                  left: 0,
                  right: 0,
                  child: Column(
                    children: [
                      CustomButton(
                        onPressed: () {
                          launch(locationUrl);
                        },
                        text: 'عرض الموقع على الخريطة',
                        icon: Icons.map,
                        buttonWidth: 180, // تحديد العرض هنا
                      ),
                      SizedBox(height: 10), // تقليل المسافة بين الزرين
                      CustomButton(
                        onPressed: () {
                          launch(videoUrl);
                        },
                        text: 'شاهد الفيديو',
                        icon: Icons.video_library,
                        buttonWidth: 180, // تحديد العرض هنا
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              _getLandmarkDescription(landmarkName), // استدعاء الوصف للمعلم
              style: TextStyle(fontSize: 16),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }

  // دالة للحصول على الوصف لكل معلم
  String _getLandmarkDescription(String landmarkName) {
    switch (landmarkName) {
      case 'الأهرامات':
        return 'الأهرامات هي تحفة من تحف مصر القديمة تعود إلى العصور الفرعونية، وهي من أهم المعالم السياحية في القاهرة وتجذب الملايين من الزوار سنويًا.';
      case 'المتحف المصري':
        return 'المتحف المصري هو متحف يضم آثار وتحفًا قديمة من عصور مصر القديمة، ويعتبر واحدًا من أهم المتاحف في العالم.';
      case 'قلعة صلاح الدين الايوبي':
        return 'قلعة صلاح الدين الأيوبي هي قلعة تاريخية تقع في قلب مدينة القاهرة، وتعتبر شاهدًا على الفترة الإسلامية في مصر.';
      case 'خان الخليلي':
        return 'خان الخليلي هو سوق تقليدي في مدينة القاهرة يعود تاريخه لعصور ما قبل الإسلام، ويعتبر وجهة تسوق شهيرة للسياح.';
      case 'قلعة قايتباي':
        return 'قلعة قايتباي هي قلعة تاريخية تقع على شاطئ البحر في مدينة الإسكندرية، وتُعتبر واحدة من أهم المعالم التاريخية في المدينة.';
      case 'المكتبة الإسكندرية':
        return 'المكتبة الإسكندرية هي إحدى أشهر المكتبات في العالم القديم، وتعتبر رمزًا للثقافة والتعليم في مصر.';
      case 'متحف المجوهرات الملكية':
        return 'متحف المجوهرات الملكية يضم مجموعة من المجوهرات والمقتنيات الفاخرة التي كانت تخص عائلة العلويين الملكية في مصر.';
      case 'معبد الكرنك':
        return 'معبد الكرنك هو معبد مصري قديم يعود تاريخه للعصور الفرعونية، ويُعتبر أحد أهم المعابد الدينية في الأقصر.';
      case 'وادي الملوك':
        return 'وادي الملوك هو موقع أثري يضم مقابر فراعنة مصر القديمة، ويُعتبر واحدًا من أهم المواقع الأثرية في مصر.';
      case 'معبد الأقصر':
        return 'معبد الأقصر هو معبد يعود للعصور الفرعونية في مصر، ويُعتبر أحد أهم المعالم السياحية في مدينة الأقصر.';
      case 'معبد فيلة':
        return 'معبد فيلة هو معبد قديم يعود للعصور الفرعونية في مصر، ويُعتبر موقعًا مهمًا للحضارة المصرية القديمة.';
      case 'معبد أبو سمبل':
        return 'معبد أبو سمبل هو معبد يعود للعصور الفرعونية في مصر، ويُعتبر موقعًا أثريًا مهمًا يستقطب العديد من الزوار.';
      case 'خليج نعمة':
        return 'خليج نعمة هو شاطئ رملي يقع في مدينة شرم الشيخ، ويُعتبر واحدًا من أجمل الشواطئ في شبه جزيرة سيناء.';
      case 'محمية رأس محمد':
        return 'محمية رأس محمد هي محمية طبيعية تقع في جنوب شبه جزيرة سيناء، وتُعتبر وجهة مثالية لمحبي الطبيعة والغوص.';
      case 'مسجد الصحابة':
        return 'مسجد الصحابة هو مسجد تاريخي يقع في مدينة شرم الشيخ، ويُعتبر مكانًا مقدسًا للمسلمين.';
      default:
        return 'قلعة صلاح الدين الأيوبي هي قلعة تاريخية تقع في قلب مدينة القاهرة، وتعتبر شاهدًا على الفترة الإسلامية في مصر';
    }
  }
}
