package com.example.ahmed_hossam

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
